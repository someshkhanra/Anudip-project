package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.FlightDTO;
import com.airline.repository.AirlineRepository;
import com.airline.repository.FlightRepository;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;

@Service
public class FlightServiceImpl implements FlightService{
	
	//logger statically created
	private static final Logger L=LoggerFactory.getLogger(FlightService.class);

	@Autowired
	FlightRepository flightRepository;
	
	@Autowired
	FlightConverter flightConverter;
	
	@Autowired
	AirlineRepository airlineRepository;
	
	
	//Implementation of add flight Service
	
	@Override
	public FlightDTO saveFlight(Flight flight) {
	   Flight fl =flightRepository.save(flight);
	   L.info("Flight"+flight.toString()+" added at "+ new java.util.Date());
		return flightConverter.convertToFlightDTO(fl);
	}

	
	//Implementation of assingAirlineToflight Service
	
	@Override
	public FlightDTO assignAirlineToFlight(int flightId, int airlineId)
	{
		Flight flight=flightRepository.findById(flightId).get();
		Airline airline=airlineRepository.findById(airlineId).get();
		
		flight.setAirline(airline);
		
		Flight f=flightRepository.save(flight);
		
		  L.info("Flight"+flight.toString()+" fid "+flightId+" assing to "+ " aid "+airlineId+ " at "+ new java.util.Date());
		
		return flightConverter.convertToFlightDTO(f);
	}
	//Implementation of searchflight Service

	@Override
	public  List<FlightDTO> searchFlight(String source, String destination) {
			List<Flight> flights=flightRepository.findBySourceAndDestination(source, destination);
			List<FlightDTO> flightDTO= new ArrayList<>();
			
			for(Flight f: flights)
			{
				flightDTO.add(flightConverter.convertToFlightDTO(f));
			}
			  L.info("Searching Flights by source "+source+" and destination "+destination+  " at "+ new java.util.Date());
			return flightDTO;
	}


	@Override
	public FlightDTO updateFlight(int id, Flight flight) {
		//we need to check whether Flight with given id is exist in DB or not
		
				Flight existingFlight=flightRepository.findById(id).orElseThrow(()->
				new ResourceNotFoundException("Flight", "id", id));
				
				//we will get data from client and set in existing passenger
				existingFlight.setAvailableSeats(flight.getAvailableSeats());
				existingFlight.setTotalSeats(flight.getTotalSeats());
				existingFlight.setTravellerClass(flight.getTravellerClass());
				existingFlight.setTime(flight.getTime());
				existingFlight.setDate(flight.getDate());
				existingFlight.setSource(flight.getSource());
				existingFlight.setDestination(flight.getDestination());
				
				flightRepository.save(existingFlight);
				  L.info("Flight"+flight.toString()+" updated at "+ new java.util.Date());
				return flightConverter.convertToFlightDTO(existingFlight);
	}

	//Service layer for getFlightById
	@Override
	public FlightDTO getFlightById(int id) {
		Flight flight =flightRepository.findById(id).orElseThrow(()->
        new ResourceNotFoundException("Flight", "id", id));
		L.info("Getting flights By "+id+" at "+ new java.util.Date());
		return flightConverter.convertToFlightDTO(flight);
	}

	
	//Service layer for getAllFlight
	@Override
	public List<FlightDTO> getAllFlight() {
		List<Flight> flights =flightRepository.findAll();
		
		List<FlightDTO> flightDTOs=new ArrayList<>();
		for(Flight flight : flights)
		{
			flightDTOs.add(flightConverter.convertToFlightDTO(flight));
		}
		L.info("Getting all flights details"+" at "+ new java.util.Date());
		return flightDTOs;
	}

	
	//Service layer for deleteFlight
	@Override
	public String deleteFlight(int id) {
		String msg=null;
		Optional<Flight> opFlight =flightRepository.findById(id);
		if(opFlight.isPresent())
		{
			flightRepository.deleteById(id);
			msg="Record deleted successfully!!";
			
			L.info("deleteing this flight  "+id+" at "+ new java.util.Date());
		}
		else
		{
			throw new ResourceNotFoundException("Flight", "ID", id);
		}
		return msg;
	}
		
	

	

}
