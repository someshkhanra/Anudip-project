package com.airline.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.airline.entity.Passenger;
import com.airline.model.PassengerDTO;

@Component
public class PassengerConverter {

	//convert from PassengerDTO to Entity(Passenger)
	public Passenger covertToPassengerEntity(PassengerDTO passengerDTO)
	{
		Passenger passenger=new Passenger();
		if(passengerDTO!=null)
		{
			BeanUtils.copyProperties(passengerDTO, passenger);
		}
		return passenger;
	}
	
	
	//covert from passenger Entity to PassengerDTO
	public PassengerDTO convertToPassengerDTO(Passenger passenger)
	{
		PassengerDTO passengerDTO=new PassengerDTO();
		if(passenger!=null)
		{
			BeanUtils.copyProperties(passenger, passengerDTO);
		}
		return passengerDTO;
	}
	
}
