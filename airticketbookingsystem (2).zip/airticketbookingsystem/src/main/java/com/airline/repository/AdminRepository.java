package com.airline.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.airline.entity.Admin;


public interface AdminRepository extends JpaRepository<Admin, Integer>
{
	

	@Query("select a from Admin a where a.aname=?1")
	List<Admin> getAdminByName(String aname);
	
	@Query("select a from Admin a where a.aemail=:e")
	Admin getAdminByEmail(@Param("e") String aemail);
}
