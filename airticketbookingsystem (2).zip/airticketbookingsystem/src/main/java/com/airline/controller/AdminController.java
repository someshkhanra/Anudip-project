package com.airline.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entity.Admin;
import com.airline.entity.Passenger;
import com.airline.model.AdminDTO;
import com.airline.model.PassengerDTO;
import com.airline.service.AdminService;
import com.airline.util.AdminConverter;

@RestController
@RequestMapping("/api")
public class AdminController
{
	@Autowired
	private	AdminService adminService;
	
	@Autowired
	AdminConverter adminConverter;
	
	
	//build create admin REST API
	@PostMapping("/createAdmin")
	public String createAdmin(@Valid @RequestBody AdminDTO adminDTO)
	{
		final Admin admin=adminConverter.covertToAdminEntity(adminDTO);
		return adminService.createAdmin(admin);
	}
	
	
	//build update passenger REST API
		//localhost:8086/updatePassenger/2
		@PutMapping("/updateAdmin/{id}")
		public ResponseEntity<AdminDTO> updateAdmin(@Valid @PathVariable("id") int id,
			@RequestBody AdminDTO adminDTO )
		{
			final Admin admin=adminConverter.covertToAdminEntity(adminDTO);
			return new ResponseEntity<AdminDTO>(adminService.updateAdmin(id, admin),
					HttpStatus.OK);
		}
		
		//build GET passenger REST API
		@GetMapping("/getAdminById/{id}")
		public AdminDTO getadminById(@PathVariable int id)
		{
			return adminService.getAdminById(id);
		}
		
	
		
		 //build GET ALL passenger REST API
		@GetMapping("/getAllAdmin")
		public List<AdminDTO> getAlladmin()
		{
			return adminService.getAllAdmin();
		}
		
		 //build delete passenger REST API
		@DeleteMapping("/deleteAdmin/{id}")
		public String deleteAdmin(@PathVariable int id)
		{
			return adminService.deleteAdmin(id);
		}
		
		 //build get by passenger name REST API
		@GetMapping("/getAdminByName/{aname}")
		public List<AdminDTO> getAdminByName(@PathVariable("aname") String aname)
		{
			return adminService.getAdminByName(aname);
		}
		
		 //build get by passenger email REST API
		@GetMapping("/getAdminByEmail/{aemail}")
		public AdminDTO getAdminByEmail(@PathVariable("aemail") String aemail)
		{
			return adminService.getAdminByEmail(aemail);
		}
	
	

}
