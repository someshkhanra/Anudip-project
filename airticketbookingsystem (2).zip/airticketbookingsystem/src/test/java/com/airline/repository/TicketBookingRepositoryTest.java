package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.airline.entity.TicketBooking;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TicketBookingRepositoryTest {
	
	@Autowired
	private TicketBookingRepository ticketBookingRepository;
	
	//this method is for testing ticketBooking Repository layer
	@Test
	@DisplayName("ticketBooking method")
	void bookTicketTest()
	{
		TicketBooking ticketBooking=TicketBooking.builder().noOfPassenger(2).source("kolkata").
				destination("mumbai").build();
	
		TicketBooking t=ticketBookingRepository.save(ticketBooking);
	
		assertThat(t.getSource()).isEqualTo("kolkata");
	}

}
