package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.airline.entity.Airline;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AirlineRepositoryTest 
{
	@Autowired
	private AirlineRepository airlineRepository;
	
	//this method is for testing saveAirline Repository layer
	
	@Test
	@DisplayName("saveAirline method")
	@Order(1)
	void saveAirlineTest()
	{
		Airline airline=Airline.builder().airlineName("vistara").fare(5000.55f).build();
		
		Airline a=airlineRepository.save(airline);
		
		assertThat(a.getAirlineName()).isEqualTo("vistara");
	}
	
	//this method is for testing getAllAirline Repository layer
	@Test
	@DisplayName("getAllAirline method")
	@Rollback(value = false)
	@Order(3)
	void getAllAirlineTest()
	{
		List<Airline> list=airlineRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
	}
	
	//this method is for testing updateAirline Repository layer
	
	@Test
	@DisplayName("updateAirline method")
	@Rollback(value = false)
	@Order(2)
	void updateAirlineTest()
	{
		Airline exAir=airlineRepository.findById(6).get();
		exAir.setAirlineName("Indigo");
		
		Airline a=airlineRepository.save(exAir);
		assertThat(a.getAirlineName()).isEqualTo("Indigo");
	}
	
	
	//this method is for testing deleteAirline Repository layer
	@Test
	@DisplayName("deleteAirline method")
	@Order(4)
	void deleteAirline()
	{
		airlineRepository.deleteById(6);
		assertThrows(NoSuchElementException.class,()-> airlineRepository.findById(6).get());
		
	}
	
	//this method is for testing negative case updateAirline Repository layer
	@Test
	@DisplayName("negative test case")
	@Rollback(value = false)
	@Order(5)
	void updateAirlineNegative()
	{
		Airline exAir=airlineRepository.findById(6).get();
		exAir.setAirlineName("vistara");
		Airline a=airlineRepository.save(exAir);
		
		assertThat(a.getAirlineName()).isEqualTo("Air India");
	}
}
