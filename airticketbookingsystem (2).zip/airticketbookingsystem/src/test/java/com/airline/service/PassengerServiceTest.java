package com.airline.service;



import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import com.airline.entity.Passenger;
import com.airline.model.PassengerDTO;
import com.airline.repository.PassengerRepository;
import com.airline.service.PassengerService;
import com.airline.util.PassengerConverter;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
 class PassengerServiceTest
{
	//logger statically created
		private static final Logger L=LoggerFactory.getLogger(PassengerService.class);
	@Autowired
	private PassengerService passengerService;
	
	@Autowired
	private PassengerConverter passengerConverter;
	
	@MockBean
	private PassengerRepository passengerRepository;
	
	
	//this method is for testing createPassenger service layer
	
	@Test
	@DisplayName("createPassenger method")
	@Order(1)
	 void testCreatePassenger()
	{
		Passenger passenger=Passenger.builder().name("Suraj").email("suraj@gmail.com").phno("9572645390").
				userName("suraj").password("suraj123").role("user").build();
		
		Mockito.when(passengerRepository.save(passenger)).thenReturn(passenger);
		L.info("Passenger"+passenger.toString()+" added at "+ new java.util.Date());
		assertThat(passengerService.createPassenger(passenger)).isEqualTo("Passenger saved Successfully!!");
	}
	
	//this method is for testing updatePassenger service layer
	@Test
	@DisplayName("updatePassenger method")
	@Order(2)
	void testUpdatePassenger()
	{
		Passenger passenger=Passenger.builder().name("Suraj").email("surajkumar@gmail.com").phno("9113317676").
				userName("suraj").password("suraj123").role("user").build();
		
		Optional<Passenger> opPass=Optional.of(passenger);
		Mockito.when(passengerRepository.findById(passenger.getId())).thenReturn(opPass);
		
		Passenger p=opPass.get();
		passenger.setName("Suraj Kumar");
		
		Mockito.when(passengerRepository.save(passenger)).thenReturn(p);
		PassengerDTO pdto=passengerService.updatePassenger(passenger.getId(),passenger);
		L.info("Passenger"+passenger.toString()+" updated at "+ new java.util.Date());
		assertEquals(pdto.getName(), p.getName());
		
		
	}
	
	//this method is for testing getAllPassenger service layer
	@Test
	@DisplayName("getAllPassenger method")
	@Order(3)
	void testGetAllPassengers()
	{
		Passenger passenger=Passenger.builder().name("Suraj Kumar").email("surajkumar@gmail.com").phno("9113317676").
				userName("suraj").password("suraj123").role("user").build();
		
		Passenger passenger2=Passenger.builder().name("Ramesh Kumar").email("ramesh@gmail.com").phno("9572645390").
				userName("ramesh").password("ramesh123").role("user").build();
		
		List<Passenger> list=new ArrayList<>();
			list.add(passenger);
			list.add(passenger2);
			
		Mockito.when(passengerRepository.findAll()).thenReturn(list);
		
		List<PassengerDTO> dto=passengerService.getAllPassenger();
		L.info("Getting all Passenger By "+passenger.toString()+" at "+ new java.util.Date());
		List<Passenger> pass=new ArrayList<Passenger>();
		   dto.forEach(passDto ->
		   {
			   pass.add(passengerConverter.covertToPassengerEntity(passDto));
		   });
		
		   assertThat(pass).isEqualTo(list);
	}
	
	//this method is for testing deletePassenger service layer
	@Test
	@DisplayName("deletePassenger method")
	@Order(4)
	void testDeletePassenger()
	{
		Passenger passenger=Passenger.builder().name("Suraj Kumar").email("surajkumar@gmail.com").phno("9113317676").
				userName("suraj").password("suraj123").role("user").build();
		
		Optional<Passenger> opPass=Optional.of(passenger);
		Mockito.when(passengerRepository.findById(opPass.get().getId())).thenReturn(opPass);
		L.info("Deleteing  Passenger "+ passenger.toString()+" at "+ new java.util.Date());
		assertThat(passengerService.deletePassenger(opPass.get().getId())).isEqualTo("Record deleted successfully!!");
		
	}
	
	//this method is for testing positive case getPassengerById service layer
	@Test
	@DisplayName("positive test case")
	@Order(5)
	void testGetPassengerById()
	{
		Passenger passenger=Passenger.builder().name("Suraj Kumar").email("surajkumar@gmail.com").phno("9113317676").
				userName("suraj").password("suraj123").role("user").build();
		
		Optional<Passenger> opPass=Optional.of(passenger);
		Mockito.when(passengerRepository.findById(passenger.getId())).thenReturn(opPass);
		
		PassengerDTO pdto=passengerConverter.convertToPassengerDTO(passenger);
		L.info("Getting Passenger By "+passenger.getId()+" at "+ new java.util.Date());
		assertThat(passengerService.getPassengerById(passenger.getId())).isEqualTo(pdto);
		
	}
	
	
	
	//this method is for testing negative case getPassengerById service layer
	@Test
	@DisplayName("Negative test ")
	@Order(6)
	void testNegativeGetPassengerById()
	{
		Passenger passenger=Passenger.builder().name("Suraj Kumar").email("surajkumar@gmail.com").phno("9113317676").
				userName("suraj").password("suraj123").role("user").build();
		
		
		Optional<Passenger> opPass=Optional.of(passenger);
		Mockito.when(passengerRepository.findById(passenger.getId())).thenReturn(opPass);
		
		PassengerDTO pdto=passengerConverter.convertToPassengerDTO(passenger);
		L.info("Getting Passenger By "+passenger.getId()+" at "+ new java.util.Date());
		assertThat(passengerService.getPassengerById(passenger.getId())).isNotEqualTo(pdto);
		
	}


	
	
	
	
	
	
	
	
	
}
