package com.airline.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import com.airline.entity.TicketBooking;
import com.airline.repository.TicketBookingRepository;
import com.airline.service.TicketBookingService;
import com.airline.util.TicketBookingConverter;

@SpringBootTest
public class TicketBookingServiceTest
{
	//logger statically created
		private static final Logger L=LoggerFactory.getLogger(TicketBookingService.class);
	@Autowired
	TicketBookingService ticketBookingService;
	
	@Autowired
	TicketBookingConverter ticketBookingConverter;
	
	@MockBean
	TicketBookingRepository ticketBookingRepository;
	
	//this method is for testing ticketBooking service layer
	@Test
	@DisplayName("ticketBooking  method")
	@Order(1)
	 void testTicketBooking()
	{
		TicketBooking ticketBooking=TicketBooking.builder().noOfPassenger(2).
				source("kolkata").destination("mumbai").build();
		
		
		Mockito.when(ticketBookingRepository.save(ticketBooking)).thenReturn(ticketBooking);
		L.info("Admin"+ticketBooking.toString()+" added at "+ new java.util.Date());
		assertNotNull(ticketBooking);
	}
	
	
	
}
